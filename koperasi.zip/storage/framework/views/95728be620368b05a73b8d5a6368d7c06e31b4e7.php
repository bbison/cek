
<?php $__env->startSection('body'); ?>
    <?php if($pinjaman_tunggu->count() == 1): ?>
        Saat ini anda memiliki pinjaman yang menunggu verifikasi
    <?php elseif($pinjaman_aktif->count() == 1): ?>
        Saat ini anda memiliki pinjaman yang aktif
    <?php else: ?>
        <img src="<?php echo e(url('')); ?>/asset/images/promosi.jpg" alt="" width="80%" class="rounded mx-auto d-block">
        <h4 class="text-center">Ada Kebutuhan Mendadak ? Yuk Ajukan Pinjaman</h4>
        <div class="d-flex justify-content-center">
            <a href="<?php echo e(route('pinjaman.pengajuan')); ?>" class="btn btn-success">Ajukan Pinjaman</a>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projek\koperasi\resources\views/verifed/index.blade.php ENDPATH**/ ?>