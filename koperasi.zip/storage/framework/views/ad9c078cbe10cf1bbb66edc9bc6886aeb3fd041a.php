<table class="table col-7 mt-3">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3>Nama : <?php echo e($user->user->name); ?></h3>
        <h3>ID Pinjaman : <?php echo e($user->id); ?></h3>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <tr class="text-center">
        <th>Jatuh Tempo</th>
        <th>Tagihan Ke</th>
        <th>Tanggal Pelunasan</th>
        <th>Total Tagihan</th>
        <th>Status</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $data->angsuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angsuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($angsuran->jatuh_tempo); ?></td>
                <td><?php echo e($angsuran->bulan_angsuran); ?></td>
                <td>
                    <?php if($angsuran->updated_at == $angsuran->created_at): ?>
                   -
                   <?php else: ?>
                   <?php echo e($angsuran->updated_at); ?>

                    <?php endif; ?>
                </td>
                <td>Rp. <?php echo number_format(intval(intval($data->nominal_pinjaman) / intval($data->lama_pinjaman)),0,',','.'); ?></td>
                <td>
                    <?php if($angsuran->status == 'Belum Bayar'): ?>
                        <div class="btn btn-warning text-white"> <strong>Belum Bayar</strong> </div>
                        <?php if(intval($angsuran->bulan_angsuran)==$ke): ?>
                            <small class="text-danger d-block">*Pembayaran ini</small>
                        <?php endif; ?>
                    <?php elseif($angsuran->status == 'Sudah Bayar'): ?>
                        <div class="btn btn-success text-white"> <strong>Lunas</strong> </div>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH E:\Projek\koperasi\resources\views/ajax/pembayaran.blade.php ENDPATH**/ ?>