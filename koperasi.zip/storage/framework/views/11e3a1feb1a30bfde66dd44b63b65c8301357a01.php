
<?php $__env->startSection('body'); ?>
    <div class="col-12 d-flex justify-content-center">
        <main class="col-11">
            
            <div class="ms-3 text-center fs-1">Daftar Anggota</div>
            <div class="d-flex ms-3 me-3 justify-content-between">
                <button type="button" class="btn btn-success text-white col-2" data-bs-toggle="modal"
                    data-bs-target="#tambah">Tambah
                    Anggota
                </button>
                <div class="col-4">
                    <form action="" method="get">
                        <input type="text" name="filter" class="form-control" placeholder="cari ID atau Nama"
                            onkeyup="anggota(this.value)">
                    </form>
                </div>


                <!-- Modal tambah anggota -->
                <div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <form action="<?php echo e(route('anggota.tambah')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Anggota</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Nama</label>
                                        <input type="text" name="name" placeholder="Contoh: KOPERASI SUBUR MAKMUR"
                                            class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Simpanan Wajib</label>
                                        <input type="text" name="simpanan_Wajib" placeholder="Contoh: 500000 "
                                            class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Simpanan Pokok</label>
                                        <input type="text" name="simpanan_pokok" placeholder="Contoh: 500000 "
                                            class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">SImpanan Sukarela</label>
                                        <input type="text" name="simpanan_sukarela" placeholder="Contoh: 500000 "
                                            class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Tambah</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
            <?php if(session('pesan')): ?>
                <div class="alert alert-success alert-dismissible m-2 fade show" role="alert">
                    <?php echo e(session('pesan')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <hr>
            <div class="d-flex justify-content-center mt-3" id="hasil">

                <table class="table col-7">
                    <tr class="text-center">
                        <th>NO</th>
                        <th>ID</th>
                        <th>NAMA ANGGOTA</th>
                        <th>TANGGAL MASUK</th>
                        <th>SIMPANAN WAJIB</th>
                        <th>SIMPANAN POKOK</th>
                        <th>SIMPANAN SUKARELA</th>
                        <th>ACTION</th>
                    </tr>
                    <?php $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($anggota->id); ?></td>
                            <td><?php echo e($anggota->name); ?></td>
                            <td><?php echo e($anggota->created_at); ?></td>
                            <td> Rp. <?php echo number_format($anggota->simpanan_wajib,0,',','.'); ?> </td>
                            <td> Rp. <?php echo number_format($anggota->simpanan_pokok,0,',','.'); ?> </td>
                            <td> Rp. <?php echo number_format($anggota->simpanan_sukarela,0,',','.'); ?> </td>

                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-success dropdown-toggle" type="button" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        Action
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item"
                                                href="/anggota/<?php echo e(Crypt::encryptString($anggota->id)); ?>">Lihat Detail</a>
                                        </li>
                                        <li><button type="button" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#edit<?php echo e($anggota->id); ?>">Edit</button>
                                        </li>
                                        <li><button type="button" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#simpananpokok<?php echo e($anggota->id); ?>">Setor Simpanan
                                                Pokok</button></li>
                                        <li><button type="button" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#simpananwajib<?php echo e($anggota->id); ?>">Setor Simpanan
                                                Wajib</button></li>
                                        <li><button type="button" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#simpanansukarela<?php echo e($anggota->id); ?>">Setor Simpanan
                                                Sukarela</button></li>
                                        <li><a class="dropdown-item" href="#">Keluar ?</a></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <!-- Modal simpanan Pokok -->
                        <div class="modal fade" id="simpananpokok<?php echo e($anggota->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <form action="<?php echo e(route('simpanan.pokok.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Simpanan Pokok</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Nama</label>
                                                <input readonly type="text" name="name"
                                                    placeholder="Contoh: KOPERASI SUBUR MAKMUR" class="form-control"
                                                    id="exampleInputEmail1" aria-describedby="emailHelp"
                                                    value="<?php echo e($anggota->name); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">ID</label>
                                                <input readonly type="text" name="id"
                                                    placeholder="Contoh: 500000 " class="form-control"
                                                    id="exampleInputEmail1" aria-describedby="emailHelp"
                                                    value="<?php echo e($anggota->id); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Simpanan Pokok</label>
                                                <input type="text" name="simpanan_pokok" placeholder="Contoh: 500000 "
                                                    class="form-control" id="exampleInputEmail1"
                                                    aria-describedby="emailHelp">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Tambah</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Modal simpanan wajib -->
                        <div class="modal fade" id="simpananwajib<?php echo e($anggota->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <form action="<?php echo e(route('simpanan.wajib.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Simpanan wajib</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Nama</label>
                                                <input readonly type="text" name="name"
                                                    placeholder="Contoh: KOPERASI SUBUR MAKMUR" class="form-control"
                                                    id="exampleInputEmail1" aria-describedby="emailHelp"
                                                    value="<?php echo e($anggota->name); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">ID</label>
                                                <input readonly type="text" name="id"
                                                    placeholder="Contoh: 500000 " class="form-control"
                                                    id="exampleInputEmail1" aria-describedby="emailHelp"
                                                    value="<?php echo e($anggota->id); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Simpanan wajib</label>
                                                <input type="text" name="simpanan_wajib" placeholder="Contoh: 500000 "
                                                    class="form-control" id="exampleInputEmail1"
                                                    aria-describedby="emailHelp">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Tambah</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Modal simpanan sukarela -->
                        <div class="modal fade" id="simpanansukarela<?php echo e($anggota->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <form action="<?php echo e(route('simpanan.sukarela.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Simpanan sukarela</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Nama</label>
                                                <input readonly type="text" name="name"
                                                    placeholder="Contoh: KOPERASI SUBUR MAKMUR" class="form-control"
                                                    id="exampleInputEmail1" aria-describedby="emailHelp"
                                                    value="<?php echo e($anggota->name); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">ID</label>
                                                <input readonly type="text" name="id"
                                                    placeholder="Contoh: 500000 " class="form-control"
                                                    id="exampleInputEmail1" aria-describedby="emailHelp"
                                                    value="<?php echo e($anggota->id); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Simpanan
                                                    sukarela</label>
                                                <input type="text" name="simpanan_sukarela"
                                                    placeholder="Contoh: 500000 " class="form-control"
                                                    id="exampleInputEmail1" aria-describedby="emailHelp">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Tambah</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Modal edit anggota -->
                        <div class="modal fade" id="edit<?php echo e($anggota->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <form action="<?php echo e(route('anggota.update')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Anggota</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Nama</label>
                                                <input type="text" name="name"
                                                    placeholder="Contoh: KOPERASI SUBUR MAKMUR" class="form-control"
                                                    id="exampleInputEmail1" aria-describedby="emailHelp"
                                                    value="<?php echo e($anggota->name); ?>">
                                            </div>
                                            <input type="hidden" value="<?php echo e($anggota->id); ?>" name="id">
                                            
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Tanggal Masuk</label>
                                                <input type="date" name="created_at" placeholder="Contoh: 500000 "
                                                    class="form-control" id="exampleInputEmail1"
                                                    aria-describedby="emailHelp"
                                                    value="<?php echo e(\Carbon\Carbon::parse($anggota->created_at)->format('Y-m-d')); ?>">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Tambah</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </main>

    </div>
    <script>
        function anggota($filter) {

            if ($filter.length == 0) {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("hasil").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "/ajax/anggota-kosong", true);
                xmlhttp.send();
            } else if ($filter.length >= 0) {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("hasil").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "/ajax/anggota/" + $filter, true);
                xmlhttp.send();

            }

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projek\koperasi\resources\views/anggota/daftar.blade.php ENDPATH**/ ?>