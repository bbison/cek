
<?php $__env->startSection('body'); ?>
    <div class="col-12 d-flex justify-content-center">
        <main class="col-11">
            <div class="d-flex justify-content-center mt-3">

                <div class="col-8">
                    <div class="h3 text-center">Sisa Hasil Usaha</div>
                    <button type="button" class="btn btn-success text-white col-2 mb-3" data-bs-toggle="modal"
                        data-bs-target="#tambah">Tambah
                        SHU
                    </button>
                    <!-- Modal tambah shu -->
                    <div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <form action="<?php echo e(route('shu.tambah')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah SHU</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">BESAR SHU</label>
                                            <input type="text" name="besarshu" placeholder="Contoh: 5000000"
                                                class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Tambah</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <?php if(session('pesan')): ?>
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <?php echo e(session('pesan')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                    <table class="table col-6">
                        <tr class="text-center table-secondary">
                            <th>NO</th>
                            <th>ID SHU</th>
                            <th>TAHUN</th>
                            <th>BESAR SHU</th>
                            <th>ACION</th>
                        </tr>
                        <?php $__currentLoopData = $shu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($shu->id); ?></td>
                                <td><?php echo e($shu->created_at); ?></td>
                                <td>Rp. <?php echo number_format($shu->besar_shu,0,',','.'); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-success dropdown-toggle" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                            Action
                                        </button>
                                        <ul class="dropdown-menu">
                                            </li>
                                            <li><button type="button" class="dropdown-item" data-bs-toggle="modal"
                                                    data-bs-target="#edit<?php echo e($shu->id); ?>">Edit</button>
                                            </li>
                                            <li>
                                                <form action="/shu/<?php echo e($shu->id); ?>" method="post" class="">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="dropdown-item" type="submit">Hapus</button>
                                                </form>
                                            </li>
                                            <li>
                                                <form action="<?php echo e(route('shu.bagi')); ?>" method="post" class="">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" value="<?php echo e($shu->id); ?>" name="id_shu">
                                                    <button class="dropdown-item" type="submit">Bagi SHU</button>
                                                </form>
                                            </li>
                                            <li><a class="dropdown-item" href="/shu-penerima/<?php echo e($shu->id); ?>">Penerima SHU</a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <!-- Modal edit shu -->
                            <div class="modal fade" id="edit<?php echo e($shu->id); ?>" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <form action="<?php echo e(route('shu.edit')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">EDIT SHU</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="exampleInputEmail1" class="form-label">BESAR SHU</label>
                                                    <input type="text" name="besarshu" placeholder="Contoh: 5000000"
                                                        class="form-control" id="exampleInputEmail1"
                                                        aria-describedby="emailHelp" value="<?php echo e($shu->besar_shu); ?>">
                                                </div>
                                                <input type="hidden" value="<?php echo e($shu->id); ?>" name="idshu"
                                                    id="">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Tambah</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                </div>

            </div>
        </main>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projek\koperasi\resources\views/shu/index.blade.php ENDPATH**/ ?>