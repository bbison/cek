<table class="table col-7" id="hasil">
    <tr class="text-center">
        <th>NO</th>
        <th>NAMA</th>
        <th>ID PINJAMAN</th>
        <th>TOTAL PINJAMAN</th>
        <th>BUNGA</th>
        <th>STATUS</th>
        <th>ACTION</th>
    </tr>
    <?php $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="text-center">
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($p->user->name); ?></td>
        <td><?php echo e($p->id); ?></td>
        <td>Rp. <?php echo number_format($p->nominal_pinjaman,0,',','.'); ?></td>
        <td><?php echo e($p->bunga); ?> %</td>
        <td> <?php if($p->status_pinjaman == 'Menunggu Verifikasi'): ?>
            <button class="btn btn-warning text-white"><?php echo e($p->status_pinjaman); ?></button> 
        <?php elseif($p->status_pinjaman == 'Aktif'): ?>
        <button class="btn btn-danger text-white"><?php echo e($p->status_pinjaman); ?></button> 
        <?php elseif($p->status_pinjaman == 'Selesai'): ?>
        <button class="btn btn-primary text-white"><?php echo e($p->status_pinjaman); ?></button> 
        <?php endif; ?>
            
        </td>
        <td>
            <div class="dropdown">
                <button class="btn btn-success dropdown-toggle" type="button" data-bs-toggle="dropdown"
                    aria-expanded="false">
                    Action
                </button>
                <ul class="dropdown-menu">
                    <li>
                        <form action="/validasi-pinjaman/<?php echo e($p->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item">Validasi</button>
                        </form>
                    </li>
                    <li>
                        <a class="dropdown-item" href="">Lihat Detail</a>
                    </li>
                </ul>
            </div>
        </td>
    </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</table><?php /**PATH E:\Projek\koperasi\resources\views/ajax/validasi.blade.php ENDPATH**/ ?>