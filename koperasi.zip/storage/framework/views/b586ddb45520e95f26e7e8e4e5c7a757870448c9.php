<table class="table-bordered border-secondary">
    <tr class="text-center">
        <th>Jatuh Tempo</th>
        <th>Tagihan</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="text-center">
        <td> <?php echo e($item); ?></td>
        <td>Rp. <?php echo number_format($tagihan,0,',','.'); ?></td>
    </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH E:\Projek\koperasi\resources\views/ajax/pengajuan.blade.php ENDPATH**/ ?>