
<?php $__env->startSection('body'); ?>
<div class="d-flex justify-content-center">
    <main class="col-11">
        <div class="text-center fs-3 mt-2 mb-3"> PINJAMAN</div>
        <div class="col-4 m-2">
            <input type="text" class="form-control" onkeyup="filter(this.value)" name="" id="" placeholder="cari Nama, ID PINJAMAN, atau Status Pinjaman">
        </div>
        <div id="hasil">
            
            <table class="table col-7">
                <tr class="text-center">
                    <th>NO</th>
                    <th>NAMA</th>
                    <th>ID PINJAMAN</th>
                    <th>TOTAL PINJAMAN</th>
                    <th>LAMA PINJAMAN</th>
                    <th>BUNGA</th>
                    <th>STATUS</th>
                    <th>ACTION</th>
                </tr>
                <?php $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($p->user->name); ?></td>
                    <td><?php echo e($p->id); ?></td>
                    <td>Rp. <?php echo number_format($p->nominal_pinjaman,0,',','.'); ?></td>
                    <td><?php echo e($p->lama_pinjaman); ?> Bulan</td>
                    <td><?php echo e($p->bunga); ?> %</td>
                    <td> <?php if($p->status_pinjaman == 'Menunggu Verifikasi'): ?>
                        <button class="btn btn-warning text-white"><?php echo e($p->status_pinjaman); ?></button> 
                    <?php elseif($p->status_pinjaman == 'Aktif'): ?>
                    <button class="btn btn-danger text-white"><?php echo e($p->status_pinjaman); ?></button> 
                    <?php elseif($p->status_pinjaman == 'Selesai'): ?>
                    <button class="btn btn-primary text-white"><?php echo e($p->status_pinjaman); ?></button> 
                    <?php endif; ?>
                        
                    </td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-success dropdown-toggle" type="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                Action
                            </button>
                            <ul class="dropdown-menu">
                                <li>
                                    <form action="/validasi-pinjaman/<?php echo e($p->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item">Validasi</button>
                                    </form>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="">Lihat Detail</a>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </table>
        </div>
       </main>
</div>
<script>
      function filter(str) {
        if(str == ""){
            let st = "PaRaMeTeR"
            var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("hasil").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "/ajax/validasi/"+st, true);
                xmlhttp.send();
        }
        else{
            var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("hasil").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "/ajax/validasi/"+str, true);
                xmlhttp.send();

        }
           
              
            
        
        }
</script>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projek\koperasi\resources\views/pinjaman/validasi.blade.php ENDPATH**/ ?>