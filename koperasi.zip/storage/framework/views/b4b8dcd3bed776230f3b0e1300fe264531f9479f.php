
<?php $__env->startSection('body'); ?>
    <div class="col-12 d-flex justify-content-center mt-3">
        <main class="col-11">
            <table class="table col-6">
                <tr class="text-center table-secondary">
                    <th>NO</th>
                    <th>NAMA</th>
                    <th>TAHUN</th>
                    <th>BESAR SHU</th>
                </tr>
                <?php $__currentLoopData = $penerima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($p->nama); ?></td>
                        <td><?php echo e($p->created_at); ?></td>
                        <td><?php echo e($p->nominal); ?></td>
                    </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projek\koperasi\resources\views/shu/penerima.blade.php ENDPATH**/ ?>