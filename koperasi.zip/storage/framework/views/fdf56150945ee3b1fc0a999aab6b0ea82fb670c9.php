
<?php $__env->startSection('body'); ?>
    <div class="col-12 d-flex justify-content-center">
        <main class="col-11 row">
            <div class="col-8">
                <?php if($pinjaman_aktif->count() != 0): ?>
                    <div class="fs-3 mt-3 text-center">Pinjaman Aktif</div>
                    <hr>
                    <div class="d-flex justify-content-center">
                        <table class="table col-7">
                            <tr class="text-center">
                                <th>Tagihan</th>
                                <th>Jatuh Tempo</th>
                                <th>Total Tagihan</th>
                                <th>Status</th>
                            </tr>
                            <?php $__currentLoopData = $pinjaman_aktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angsuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $angsuran->angsuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angsuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td>Bulan <?php echo e($angsuran->tagihan_angsuran); ?></td>
                                        <td><?php echo e($angsuran->jatuh_tempo); ?></td>
                                        <td>Rp. <?php echo number_format(intval($angsuran->tagihan_angsuran),0,',','.'); ?></td>
                                        <td>
                                            <?php if($angsuran->status == 'Belum Bayar'): ?>
                                                <div class="btn btn-warning text-white"> <strong>Belum Bayar</strong> </div>
                                            <?php elseif($angsuran->status == 'Sudah Bayar'): ?>
                                                <div class="btn btn-success text-white"> <strong>Lunas</strong> </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                <?php elseif($pinjaman_tunggu->count() == 1): ?>
                    <div class="">Pinjaman Menunggu verifikasi</div>
                <?php else: ?>
                    <div class="text-center fs-3 mt-3">Belum Ada Pinjaman</div>
                <?php endif; ?>
            </div>




            <div class="col-4">
                <div class="ms-3 fs-3 mt-3">Riwayat Pinjaman</div>
                <hr>
                <?php if(auth()->user()->pinjaman->count() <= 0): ?>
                    <div class="fs-5">
                        Belum Ada Riwayat Pinjaman
                    </div>                    
                <?php else: ?>
                <table class="table">
                    <tr>
                        <th>Nominal</th>
                        <th>ID Pinjaman</th>
                        <th>Status</th>
                    </tr>
                    <?php $__currentLoopData = auth()->user()->pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>Rp. <?php echo number_format($p->nominal_pinjaman,0,',','.'); ?></td>
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e($p->status_pinjaman); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

                <?php endif; ?>
              
            </div>

        </main>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projek\koperasi\resources\views/pinjaman/index.blade.php ENDPATH**/ ?>