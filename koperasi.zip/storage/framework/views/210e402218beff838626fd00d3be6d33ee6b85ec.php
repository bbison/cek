
<?php $__env->startSection('body'); ?>
    <div class="col-12 d-flex justify-content-center">
        <main class="col-11">
            <div class="ms-3 btn btn-success mt-3">Total Simpanan Pokok Rp. <?php echo number_format(auth()->user()->simpanan_pokok,0,',','.'); ?> </div>
            <div class="ms-3 btn btn-success mt-3">Total Simpanan Wajib Rp. <?php echo number_format(auth()->user()->simpanan_wajib,0,',','.'); ?> </div>
            <div class="ms-3 btn btn-success mt-3">Total Simpanan suka Rela Rp. <?php echo number_format(auth()->user()->simpanan_sukarela,0,',','.'); ?> </div>
            <div class="d-flex justify-content-center mt-3">
                <div class="row col-12">
                    <div class="col-6">
                        <div class="h3 text-center">Simpanan Wajib</div>
                        <table class="table col-6">
                            <tr class="text-center table-secondary">
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                                <th>Simpanan Wajib</th>
                            </tr>
                            <?php $__currentLoopData = auth()->user()->simpananWajib; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($item->created_at); ?></td>
                                <td></td>
                                <td>Rp. <?php echo number_format($item->simpanan_wajib,0,',','.'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center table-secondary">
                                <th>Total</th>
                                <th></th>
                                <th>Rp. <?php echo number_format(auth()->user()->simpanan_wajib,0,',','.'); ?></th>
                            </tr>
                           
                        </table>
                    </div>
                    <div class="col-6">
                        <div class="h3 text-center">Simpanan Suka Rela</div>
                        <table class="table col-6">
                            <tr class="text-center table-secondary">
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                                <th>Simpanan Wajib</th>
                            </tr>
                            <?php $__currentLoopData = auth()->user()->simpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($item->created_at); ?></td>
                                <td></td>
                                <td>Rp. <?php echo number_format($item->simpanan_suka_rela,0,',','.'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center table-secondary">
                                <th>Total</th>
                                <th></th>
                                <th>Rp. <?php echo number_format(auth()->user()->simpanan_sukarela,0,',','.'); ?></th>
                            </tr>
                        </table>
                    </div>

                    <div class="col-6">
                        <div class="h3 text-center">Sisa Hasil Usaha</div>
                        <table class="table col-6">
                            <tr class="text-center table-secondary">
                                <th>Tahun</th>
                                <th>Keterangan</th>
                                <th>Nominal</th>
                            </tr>
                            <?php $__currentLoopData = auth()->user()->pembagian_shu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($item->created_at); ?></td>
                                <td></td>
                                <td>Rp. <?php echo number_format($item->nominal,0,',','.'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center table-secondary">
                                <th>Total</th>
                                <th></th>
                                <th>Rp. <?php echo number_format(auth()->user()->simpanan_sukarela,0,',','.'); ?></th>
                            </tr>
                        </table>
                    </div>

                </div>

            </div>
        </main>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projek\koperasi\resources\views/simpanan/index.blade.php ENDPATH**/ ?>