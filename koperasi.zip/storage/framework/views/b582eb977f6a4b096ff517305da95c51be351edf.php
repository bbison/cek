<div class="d-flex justify-content-center">
    <div class="col-8 mt-3">
        <div class="fs-3 text-center">Simpanan Wajib</div>
        <hr>
        <table class="table table-borderless mt-2 text-center fs-5">
            <tr>
                <th>Tanggal</th>
                <th>Nominal</th>

            </tr>
            <?php $__currentLoopData = $anggota->simpananWajib; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $simpanan_wajib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($simpanan_wajib->created_at); ?></td>
                    <td>Rp. <?php echo number_format($simpanan_wajib->simpanan_wajib,0,',','.'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th>Total</th>
                <th>Rp. <?php echo number_format($anggota->simpanan_wajib,0,',','.'); ?></th>
            </tr>
        </table>

    </div>

</div>
<?php /**PATH E:\Projek\koperasi\resources\views/ajax/simpanan_wajib.blade.php ENDPATH**/ ?>