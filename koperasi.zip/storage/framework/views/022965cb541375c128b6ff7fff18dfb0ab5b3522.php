<div class="d-flex justify-content-center">
    <div class="col-8 mt-3">
        <div class="fs-3 text-center">Simpanan Sukarela</div>
        <hr>
        <table class="table table-borderless mt-2 text-center fs-5">
            <tr>
                <th>Tanggal</th>
                <th>Nominal</th>
            </tr>
            <?php $__currentLoopData = $anggota->simpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $simpanan_sukarela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($simpanan_sukarela->created_at); ?></td>
                <td>Rp. <?php echo number_format($simpanan_sukarela->simpanan_suka_rela,0,',','.'); ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th>Total</th>
                <th>Rp. <?php echo number_format($anggota->simpanan_sukarela,0,',','.'); ?></th>
            </tr>
        </table>

    </div>

</div>
<?php /**PATH E:\Projek\koperasi\resources\views/ajax/simpanan_sukarela.blade.php ENDPATH**/ ?>